using Microsoft.AspNetCore.Authentication.Cookies;

namespace PE_PRN231_SP25_000259_FE_MVC
{
	public class Program
	{
		public static void Main(string[] args)
		{
			var builder = WebApplication.CreateBuilder(args);

			// Add services to the container.
			builder.Services.AddControllersWithViews();
			string login = "/SystemAccounts/Login";
			string forbidden = "/SystemAccounts/Forbidden";


			builder.Services.AddAuthentication()
				.AddCookie(CookieAuthenticationDefaults.AuthenticationScheme, options =>
				{
					options.LoginPath = new PathString(login);
					options.AccessDeniedPath = new PathString(forbidden);
					options.ExpireTimeSpan = TimeSpan.FromMinutes(5);

				});
			var app = builder.Build();

			// Configure the HTTP request pipeline.
			if (!app.Environment.IsDevelopment())
			{
				app.UseExceptionHandler("/Home/Error");
				// The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
				app.UseHsts();
			}

			app.UseHttpsRedirection();
			app.UseStaticFiles();

			app.UseRouting();

			app.UseAuthorization();

			app.MapControllerRoute(
				name: "default",
				pattern: "{controller=Home}/{action=Index}/{id?}");

			app.Run();
		}
	}
}
