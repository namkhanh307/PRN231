﻿using System.Security.Policy;

namespace PE_PRN231_SP25_000259_FE_MVC.Models
{
    public class LoginRequest
    {
        public string Email { get; set; }
        public string Password { get; set; }
    }
}
