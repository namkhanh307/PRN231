﻿namespace PE_PRN231_SP25_000259_FE_MVC.Models;


public partial class SystemAccount
{
	public int AccountId { get; set; }

	public string Username { get; set; }

	public string Email { get; set; }

	public string Password { get; set; }

	public int? Role { get; set; }

	public bool? IsActive { get; set; }
}