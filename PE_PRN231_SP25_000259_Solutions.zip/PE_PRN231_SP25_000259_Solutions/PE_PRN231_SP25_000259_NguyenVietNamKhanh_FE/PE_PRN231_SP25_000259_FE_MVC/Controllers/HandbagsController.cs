﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;
using PE_PRN231_SP25_000259_FE_MVC.Models;
namespace PE_PRN231_SP25_000259_FE_MVC.Controllers
{
	public class HandbagsController : Controller
	{
		private readonly string APIEndPoint = "https://localhost:7039/api/";
		private readonly string MainEntity = "Handbags";
		private readonly string SubEntity = "Brands";
		private readonly string AuthenEntity = "SystemAccounts";
		private readonly string SubEntityId = "BrandId";
		private readonly string SubEntityName = "BrandName";
		private readonly string AllPermisson = "2";
		private readonly string NonePermission = "1";
		private readonly List<string> SomePermisson = ["3", "4"];


		public HandbagsController() { }

		public async Task<IActionResult> Index()
		{
			var role = HttpContext.Request.Cookies["Role"];
			if (role == null || (role != null && NonePermission.Contains(role)))
			{
				return RedirectToAction("Forbidden", AuthenEntity);
			}
			using (var httpClient = new HttpClient())
			{
				#region Add Token to header of Request

				var tokenString = HttpContext.Request.Cookies.FirstOrDefault(c => c.Key == "TokenString").Value;

				httpClient.DefaultRequestHeaders.Add("Authorization", "Bearer " + tokenString);

				#endregion


				using (var response = await httpClient.GetAsync(APIEndPoint + MainEntity + "/get"))
				{
					if (response.IsSuccessStatusCode)
					{
						var content = await response.Content.ReadAsStringAsync();
						var result = JsonConvert.DeserializeObject<List<MainEntityVM>>(content);

						if (result != null)
						{
							return View(result);
						}
					}
				}
			}
			return View(new List<MainEntityVM>());
		}
		public async Task<IActionResult> Details(string id)
		{
			var role = HttpContext.Request.Cookies["Role"];
			if (role == null || (role != null && NonePermission.Contains(role)))
			{
				return RedirectToAction("Forbidden", AuthenEntity);
			}
			using (var httpClient = new HttpClient())
			{
				#region Add Token to header of Request

				var tokenString = HttpContext.Request.Cookies.FirstOrDefault(c => c.Key == "TokenString").Value;

				httpClient.DefaultRequestHeaders.Add("Authorization", "Bearer " + tokenString);

				#endregion


				using (var response = await httpClient.GetAsync(APIEndPoint + MainEntity + "/getById?id=" + id))
				{
					if (response.IsSuccessStatusCode)
					{
						var content = await response.Content.ReadAsStringAsync();
						var result = JsonConvert.DeserializeObject<MainEntityVM>(content);

						if (result != null)
						{
							return View(result);
						}
					}
				}
			}

			return View(new MainEntityVM());
		}

		public async Task<IActionResult> Search(string modelName, string material, string color)
		{
			var role = HttpContext.Request.Cookies["Role"];
			if (role == null || (role != null && NonePermission.Contains(role)))
			{
				return RedirectToAction("Forbidden", AuthenEntity);
			}
			string baseUrl = APIEndPoint + MainEntity + "/search";

			// If user entered a search query, add OData filter
			if (!string.IsNullOrWhiteSpace(modelName) || !string.IsNullOrWhiteSpace(material) || !string.IsNullOrWhiteSpace(color))
			{
				baseUrl += $"?$filter=contains(ModelName,'{modelName}') or contains(Material,'{material}') or contains(Color,'{color}')";
			}
			using (var httpClient = new HttpClient())
			{
				var tokenString = HttpContext.Request.Cookies.FirstOrDefault(c => c.Key == "TokenString").Value;
				httpClient.DefaultRequestHeaders.Add("Authorization", "Bearer " + tokenString);
				using (var response = await httpClient.GetAsync(baseUrl))
				{

					if (!response.IsSuccessStatusCode)
					{
						throw new Exception("Failed to fetch data from API");
					}

					var content = await response.Content.ReadAsStringAsync();
					var result = JsonConvert.DeserializeObject<List<MainEntityVM>>(content);
					if (result != null)
					{
						return View("Index", result);
					}
				}
			}
			return View(new List<MainEntityVM>());
		}

		public async Task<IActionResult> DeleteQuickly(string id)
		{
			var role = HttpContext.Request.Cookies["Role"];
			if (role == null || (role != null && !AllPermisson.Contains(role)))
			{
				return RedirectToAction("Forbidden", AuthenEntity);
			}
			bool deleteStatus = false;

			using (var httpClient = new HttpClient())
			{
				var tokenString = HttpContext.Request.Cookies.FirstOrDefault(c => c.Key == "TokenString").Value;
				httpClient.DefaultRequestHeaders.Add("Authorization", "Bearer " + tokenString);

				using (var response = await httpClient.DeleteAsync(APIEndPoint + MainEntity + "/delete?id=" + id))
				{
					if (response.IsSuccessStatusCode)
					{
						deleteStatus = true;
					}
				}
			}

			return RedirectToAction(nameof(Index));
		}

		// GET: cosmeticInformations/Edit/5
		public async Task<IActionResult> Edit(string id)
		{
			var role = HttpContext.Request.Cookies["Role"];
			if (role == null || (role != null && !AllPermisson.Contains(role)))
			{
				return RedirectToAction("Forbidden", AuthenEntity);
			}
			var subEntity = await GetSubEntity();

			using (var httpClient = new HttpClient())
			{
				var tokenString = HttpContext.Request.Cookies.FirstOrDefault(c => c.Key == "TokenString").Value;

				httpClient.DefaultRequestHeaders.Add("Authorization", "Bearer " + tokenString);

				using (var response = await httpClient.GetAsync(APIEndPoint + MainEntity + "/getById?id=" + id))
				{
					if (response.IsSuccessStatusCode)
					{
						var content = await response.Content.ReadAsStringAsync();
						var result = JsonConvert.DeserializeObject<Handbag>(content);

						if (result != null)
						{
							ViewData[SubEntityId] = new SelectList(subEntity, SubEntityId, SubEntityName, result.BrandId);
							return View(result);
						}
					}
				}
			}

			if (subEntity == null)
			{
				subEntity = new List<Brand>(); // Khởi tạo danh sách trống để tránh lỗi
			}

			ViewData[SubEntityId] = new SelectList(subEntity, SubEntityId, SubEntityName);
			return View(new Handbag());
		}

		// POST: cosmeticInformations/Edit/5
		// To protect from overposting attacks, enable the specific properties you want to bind to.
		// For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> Edit(Handbag mainEntity)
		{
			var role = HttpContext.Request.Cookies["Role"];
			if (role == null || (role != null && !AllPermisson.Contains(role)))
			{
				return RedirectToAction("Forbidden", AuthenEntity);
			}
			if (mainEntity == null)
			{
				// Xử lý nếu cosmeticInformation là null
				mainEntity = new Handbag();
			}

			try
			{
				using (var httpClient = new HttpClient())
				{
					var tokenString = HttpContext.Request.Cookies.FirstOrDefault(c => c.Key == "TokenString").Value;

					httpClient.DefaultRequestHeaders.Add("Authorization", "Bearer " + tokenString);

					using (var response = await httpClient.PutAsJsonAsync(APIEndPoint + MainEntity + "/update", mainEntity))
					{
						if (response.IsSuccessStatusCode)
						{
							var content = await response.Content.ReadAsStringAsync();

							if (content.Equals("Update success!"))
							{
								return RedirectToAction(nameof(Index));
							}
							else
							{
								ModelState.AddModelError("", content);
								ViewData[SubEntityId] = new SelectList(await GetSubEntity(), SubEntityId, SubEntityName, mainEntity.BrandId);
								return View(mainEntity);
							}
						}
						else
						{
							// Xử lý khi request không thành công (in ra log hoặc lỗi)
							var errorContent = await response.Content.ReadAsStringAsync();
							// Log lỗi ở đây nếu cần
						}

					}
				}
			}
			catch (DbUpdateConcurrencyException)
			{
				throw;
			}
			return View(mainEntity);
		}

		public async Task<List<Brand>> GetSubEntity()
		{
			var cosmeticCategories = new List<Brand>();

			using (var httpClient = new HttpClient())
			{
				var tokenString = HttpContext.Request.Cookies.FirstOrDefault(c => c.Key == "TokenString").Value;

				httpClient.DefaultRequestHeaders.Add("Authorization", "Bearer " + tokenString);

				using (var response = await httpClient.GetAsync(APIEndPoint + SubEntity + "/get"))
				{
					if (response.IsSuccessStatusCode)
					{
						var content = await response.Content.ReadAsStringAsync();
						cosmeticCategories = JsonConvert.DeserializeObject<List<Brand>>(content);
					}
				}
			}
			return cosmeticCategories;
		}

		// GET: cosmeticInformations/Create
		public async Task<IActionResult> Create()
		{
			var role = HttpContext.Request.Cookies["Role"];
			if (role == null || (role != null && !AllPermisson.Contains(role)))
			{
				return RedirectToAction("Forbidden", AuthenEntity);
			}
			else
			{
				ViewData[SubEntityId] = new SelectList(await GetSubEntity(), SubEntityId, SubEntityName);
				return View();
			}
		}

		// POST: cosmeticInformations/Create
		// To protect from overposting attacks, enable the specific properties you want to bind to.
		// For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> Create(Handbag mainEntity)
		{
			var role = HttpContext.Request.Cookies["Role"];
			if (role == null || (role != null && !AllPermisson.Contains(role)))
			{
				return RedirectToAction("Forbidden", AuthenEntity);
			}
			try
			{
				using (var httpClient = new HttpClient())
				{
					var tokenString = HttpContext.Request.Cookies.FirstOrDefault(c => c.Key == "TokenString").Value;

					httpClient.DefaultRequestHeaders.Add("Authorization", "Bearer " + tokenString);

					using (var response = await httpClient.PostAsJsonAsync(APIEndPoint + MainEntity + "/add", mainEntity))
					{
						if (response.IsSuccessStatusCode)
						{
							var content = await response.Content.ReadAsStringAsync();

							if (content.Equals("Add success!"))
							{
								return RedirectToAction(nameof(Index));
							}
							else
							{
								ModelState.AddModelError("", content);
								ViewData[SubEntityId] = new SelectList(await GetSubEntity(), SubEntityId, SubEntityName, mainEntity.BrandId);
								return View(mainEntity);
							}
						}
					}
				}
			}
			catch (DbUpdateConcurrencyException)
			{
				throw;
			}

			ViewData[SubEntityId] = new SelectList(await GetSubEntity(), SubEntityId, SubEntityName, mainEntity.BrandId);

			return View(mainEntity);
		}
	}
}
