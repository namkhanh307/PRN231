﻿using PE_PRN231_SP25_000259_BE_Repos.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PE_PRN231_SP25_000259_BE_Repos
{
	public interface IBaseRepo<T> where T : class
	{
		IQueryable<T> Entities { get; }
		Task<T?> GetById(string id, string pk, Func<IQueryable<T>, IQueryable<T>>? include = null);
		Task<IList<T>> Get(Func<IQueryable<T>, IQueryable<T>>? include = null);
		Task<bool> Add(T entity);
		Task<bool> Update(T entity);
		Task<bool> Delete(T entity);
		Task<SystemAccount?> Login(string email, string password);
	}
}
