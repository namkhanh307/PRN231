using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PE_PRN231_SP25_000259_BE_Repos.Models
{
	public class MainEntityVM
	{
		public int HandbagId { get; set; }

		public int? BrandId { get; set; }

		public string ModelName { get; set; }

		public string Material { get; set; }

		public string Color { get; set; }

		public decimal? Price { get; set; }

		public int? Stock { get; set; }

		public DateOnly? ReleaseDate { get; set; }
		public string BrandName { get; set; }
	}
}
