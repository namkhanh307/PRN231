using Azure.Core;
using Microsoft.EntityFrameworkCore;
using PE_PRN231_SP25_000259_BE_Repos;
using PE_PRN231_SP25_000259_BE_Repos.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace PE_PRN231_SP25_000259_BE_Services
{
	public class HandbagService
	{
		private readonly IBaseRepo<Handbag> _repo;
		private readonly IBaseRepo<Brand> _subRepo;
		private readonly string MainEntityId = "HandbagId";
		private readonly string SubEntityId = "BrandId";

		public HandbagService(IBaseRepo<Handbag> repo, IBaseRepo<Brand> subRepo)
		{
			_repo = repo;
			_subRepo = subRepo;
		}

		public async Task<string> Add(Handbag request)
		{
			var existed = await _repo.GetById(request.HandbagId.ToString(), MainEntityId);
			if (existed != null)
			{
				return "Already exist ...!";
			}
			if (string.IsNullOrWhiteSpace(request.ModelName) ||
				request.Price == null ||
				string.IsNullOrWhiteSpace(request.Material) || string.IsNullOrWhiteSpace(request.Color) || request.Stock == null || request.ReleaseDate == null || request.BrandId == null)
			{
				return "All fields are required";
			}

			if (!Regex.IsMatch(request.ModelName, @"^([A-Z][a-zA-Z0-9@#]*\s)*[A-Z][a-zA-Z0-9@#]*$"))
			{
				return "ModelName must start with a capital letter in each word and only include letters, numbers, space, @, and #.";
			}
			if (request.Price <= 0 || request.Stock <= 0)
			{
				return "Price and Stock has to > 0";
			}			

			if (await _subRepo.GetById(request.BrandId.ToString(), SubEntityId) == null)
			{
				return "Not exist ...!";

			}

			Handbag data = new Handbag()
			{
				BrandId = request.BrandId,
				Color = request.Color,
				Stock = request.Stock,
				ReleaseDate = request.ReleaseDate,
				HandbagId = request.HandbagId,
				Material = request.Material,
				Price = request.Price,
				ModelName = request.ModelName,
			};

			await _repo.Add(data);
			return "Add success!";
		}

		public async Task<IEnumerable<MainEntityVM>> Get()
		{
			var listData = await _repo.Get(a => a.Include(b => b.Brand));
			var result = listData.ToList().Select(a => new MainEntityVM()
			{
				BrandId = a.BrandId,
				Color = a.Color,
				Stock = a.Stock,
				ReleaseDate = a.ReleaseDate,
				HandbagId = a.HandbagId,
				Material = a.Material,
				Price = a.Price,
				ModelName = a.ModelName,
				BrandName = a.Brand.BrandName
			}).OrderByDescending(b => b.HandbagId);
			return result;
		}

		public async Task<string> Update(Handbag request)
		{
			var existed = await _repo.GetById(request.HandbagId.ToString(), MainEntityId);
			if (existed == null)
			{
				return "Not exist ...!";
			}
			if (string.IsNullOrWhiteSpace(request.ModelName) || request.Price == null || string.IsNullOrWhiteSpace(request.Material) || string.IsNullOrWhiteSpace(request.Color) || request.Stock == null || request.ReleaseDate == null || request.BrandId == null)
			{
				return "All fields are required";
			}

			if (!Regex.IsMatch(request.ModelName, @"^([A-Z][a-zA-Z0-9@#]*\s)*[A-Z][a-zA-Z0-9@#]*$"))
			{
				return "ModelName must start with a capital letter in each word and only include letters, numbers, space, @, and #.";
			}
			if (request.Price <= 0 || request.Stock <= 0)
			{
				return "Price and Stock has to > 0";
			}

			if (await _subRepo.GetById(request.BrandId.ToString(), SubEntityId) == null)
			{
				return "Not exist ...!";

			}

			existed.Color = request.Color;
			existed.Stock = request.Stock;
			existed.BrandId = request.BrandId;
			existed.Price = request.Price;
			existed.ReleaseDate = request.ReleaseDate;
			existed.Material = request.Material;
			await _repo.Update(existed);
			return "Update success!";
		}

		public async Task<string> Delete(string id)
		{
			var existed = await _repo.GetById(id, MainEntityId);
			if (existed == null)
			{
				return "Not exist";
			}
			await _repo.Delete(existed);
			return "Delete success!";
		}

		public async Task<IEnumerable<MainEntityVM>> Search(string? modelName, string? material, string? color)
		{
			var groupedResults = await _repo.Entities.Include(a => a.Brand).Where(u => (string.IsNullOrWhiteSpace(modelName) || u.ModelName.Contains(modelName)) &&
						(string.IsNullOrWhiteSpace(material) || u.Material.Contains(material)) &&
						(string.IsNullOrWhiteSpace(color) || u.Color.Contains(color)))
								.GroupBy(c => new { c.ModelName, c.Material, c.Color })
								.Select(g => new MainEntityVM
								{
									ModelName = g.Key.ModelName,
									Material = g.Key.Material,
									Color = g.Key.Color,
									BrandName = g.FirstOrDefault().Brand.BrandName,
									Price = g.FirstOrDefault().Price,
									ReleaseDate = g.FirstOrDefault().ReleaseDate,
									Stock = g.FirstOrDefault().Stock,
									BrandId = g.FirstOrDefault().BrandId,
									HandbagId = g.FirstOrDefault().HandbagId
								})
								.ToListAsync();

			return groupedResults;
		}


		public async Task<IEnumerable<Brand>> GetSubEntity()
		{
			return await _subRepo.Get();
		}

		public async Task<MainEntityVM> GetById(string id)
		{
			var exist = await _repo.GetById(id, MainEntityId, a => a.Include(b => b.Brand));
			if (exist == null)
			{
				return new MainEntityVM();
			}
			return new MainEntityVM
			{
				BrandId = exist.BrandId,
				Color = exist.Color,
				Stock = exist.Stock,
				ReleaseDate = exist.ReleaseDate,
				HandbagId = exist.HandbagId,
				Material = exist.Material,
				Price = exist.Price,
				ModelName = exist.ModelName,
				BrandName = exist.Brand.BrandName
			};
		}
	}
}
