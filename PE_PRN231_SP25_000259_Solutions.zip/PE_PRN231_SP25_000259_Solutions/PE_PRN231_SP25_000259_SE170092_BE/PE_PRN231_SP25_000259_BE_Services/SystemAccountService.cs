using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using PE_PRN231_SP25_000259_BE_Repos;
using PE_PRN231_SP25_000259_BE_Repos.Models;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;

namespace PE_PRN231_SP25_000259_BE_Services
{
	public class SystemAccountService
	{
		private readonly IBaseRepo<SystemAccount> _repo;
		private readonly IConfiguration _configuration;
		public SystemAccountService(IBaseRepo<SystemAccount> repo, IConfiguration configuration)
		{
			_repo = repo;
			_configuration = configuration;
		}
		public async Task<string> Login(string email, string password)
		{
			SystemAccount? account = await _repo.Login(email, password);
			var securityKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_configuration["Jwt:Key"]));
			var credentials = new SigningCredentials(securityKey, SecurityAlgorithms.HmacSha256);

			var token = new JwtSecurityToken(_configuration["Jwt:Issuer"]
					, _configuration["Jwt:Audience"]
					, new Claim[]
					{
						new(ClaimTypes.Email, account.Email),
						new(ClaimTypes.Role, account.Role.ToString()),
					},
					expires: DateTime.Now.AddMinutes(120),
					signingCredentials: credentials
				);

			var tokenString = new JwtSecurityTokenHandler().WriteToken(token);

			return tokenString;
		}

	}
}
