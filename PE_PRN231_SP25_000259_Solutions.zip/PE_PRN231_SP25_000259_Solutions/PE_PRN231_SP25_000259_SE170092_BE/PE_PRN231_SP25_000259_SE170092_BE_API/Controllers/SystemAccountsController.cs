﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using PE_PRN231_SP25_000259_BE_Services;

namespace PE_PRN231_SP25_000259_SE170092_BE_API.Controllers
{
	[Route("api/[controller]")]
	[ApiController]
	public class SystemAccountsController : ControllerBase
	{
		
		private readonly SystemAccountService _service;

		public SystemAccountsController(SystemAccountService service)
		{
			_service = service;
		}

		[HttpPost("Login")]
		public IActionResult Login([FromBody] LoginRequest request)
		{
			var user = _service.Login(request.email, request.password);
			if (user == null || user.Result == null)
				return Unauthorized();
			return Ok(user.Result);
		}
	}
	public sealed record LoginRequest(string email, string password);
	
}
