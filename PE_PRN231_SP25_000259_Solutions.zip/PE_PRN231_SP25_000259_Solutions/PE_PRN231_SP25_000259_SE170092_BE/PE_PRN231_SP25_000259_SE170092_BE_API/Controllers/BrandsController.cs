﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using PE_PRN231_SP25_000259_BE_Services;

namespace PE_PRN231_SP25_000259_SE170092_BE_API.Controllers
{
	[Route("api/[controller]")]
	[ApiController]
	public class BrandsController : ControllerBase
	{
		private readonly HandbagService _service;
        public BrandsController(HandbagService service)
        {
            _service = service;
        }
		[Authorize(Roles = "1,2,3,4")]
		[HttpGet("get")]
		public async Task<IActionResult> Get()
		{
			var result = await _service.GetSubEntity();
			return Ok(result);
		}
	}
}
