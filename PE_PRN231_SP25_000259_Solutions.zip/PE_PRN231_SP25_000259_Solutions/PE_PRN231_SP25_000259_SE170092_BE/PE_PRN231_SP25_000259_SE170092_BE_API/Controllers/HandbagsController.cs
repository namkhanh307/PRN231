﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.OData.Query;
using PE_PRN231_SP25_000259_BE_Repos.Models;
using PE_PRN231_SP25_000259_BE_Services;

namespace PE_PRN231_SP25_000259_SE170092_BE_API.Controllers
{
	[Route("api/[controller]")]
	[ApiController]
	public class HandbagsController : ControllerBase
	{
		private readonly HandbagService _service;

		public HandbagsController(HandbagService service)
		{
			_service = service;
		}
		[Authorize(Roles = "2,3,4")]
		[HttpGet("get")]
		public async Task<IActionResult> Get()
		{
			var result = await _service.Get();
			return Ok(result);
		}
		[Authorize(Roles = "2,3,4")]
		[HttpGet("getById")]
		public async Task<IActionResult> GetById(string id)
		{
			var result = await _service.GetById(id);
			return Ok(result);
		}
		[Authorize(Roles = "2,3,4")]
		[HttpGet("search")]
		[EnableQuery]
		public async Task<IActionResult> Search(string? modelName, string? material, string? color)
		{
			var result = await _service.Search(modelName, material, color);
			return Ok(result);
		}
		[Authorize(Roles = "2")]
		[HttpPost("add")]
		public async Task<IActionResult> Add(Handbag request)
		{
			var result = await _service.Add(request);
			return Ok(result);
		}
		[Authorize(Roles = "2")]
		[HttpPut("update")]
		public async Task<IActionResult> Update(Handbag request)
		{
			var result = await _service.Update(request);
			return Ok(result);
		}
		[Authorize(Roles = "2")]
		[HttpDelete("delete")]
		public async Task<IActionResult> Delete(string id)
		{
			var result = await _service.Delete(id);
			return Ok(result);
		}
	}
}
